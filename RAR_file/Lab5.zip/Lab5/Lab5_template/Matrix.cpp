#include "Matrix.h"

matrix::matrix()
{
	M = { {} };
}

matrix::matrix(int m, int n)
{
	//TO_DO: Use std::cin to initialize a matrix of size m * n
}

matrix::matrix(vector<vector<int>>& m)
{
	M = m;
}

matrix matrix::Mul(matrix m1)
{
	if (M[0].size() != m1.M.size()) 
	{
		cout << "Cannot do multiplication!" << endl;
		return matrix();
	}
	else 
	{

		//TO_DO: Multiply two matrices and print the result.
		
	}

}

void matrix::Inverse()
{

	//TO_DO: If inverse matrix exist, find and print inverse matrix.

}


bool matrix::SquareMatrix()
{

	//TO_DO: Return true if matrix is a square matrix, otherwise return fasle.
	
}

void matrix::GetDet()
{
	if (!SquareMatrix())
		cout << "Not a Square Matrix" << endl;
	else
		cout << "Determinant of matrix : " << Det(M) << endl;
	
}

int matrix::Det(vector<vector<int>>& m)
{

	//TO_DO: Compute the determinant of matrix m.
	
}

void matrix::Print()
{
	for (int i = 0; i < M.size(); i++) {
		for (int j = 0; j < M[0].size(); j++) {
			cout << M[i][j] << " ";
		}
		cout << endl;
	}
}
