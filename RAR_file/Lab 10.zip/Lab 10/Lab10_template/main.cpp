#include <iostream>
#include <fstream>
#include "BST.h"
#include "Node.h"
#include <string>
using namespace std;
void inOrderTraverse(Node* root) {
	// Inorder traverse all the node and print them out
}
int main() {
	/* For testing
	int testing_input[20] = { 5,16,3,6,21,43,15,20,10,77,1,19,33,28, 7,11,23,39,27,9 };
	inputSize = 20;
	*/
	

	system("pause");
	return 0;

}