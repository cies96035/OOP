#include "Node.h"
int Node::getValue() {

}

Node* Node::getLchild() {

}
Node* Node::getRchild() {

}

void Node::setLchild(Node* node) {

}
void Node::setRchild(Node* node) {

}