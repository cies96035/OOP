#include "BST.h"
#include <vector>
void BST::insert(Node* insertNode) {
	
}
int BST::search(int value, int mode) {

}

Node* BST::getRoot() {

}