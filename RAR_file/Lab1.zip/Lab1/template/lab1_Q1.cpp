#include "lab1_Q1.h"
#include <iostream>

using namespace std;

void MATRIX::print()
{
	/*
	PRINT MATRIX
	*/
}

void MATRIX::add(MATRIX m)
{
	/*
	ADD TWO MATRICES
	*/
}

void MATRIX::multiple(MATRIX m)
{
	/*
	MULTIPLE TWO MATRICES
	*/
}

void MATRIX::det() 
{
	/*
	CACULATE THE DETERMINANT OF THE MATRIX
	*/
}