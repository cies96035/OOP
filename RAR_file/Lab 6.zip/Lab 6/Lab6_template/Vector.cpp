#include "Vector.h"

Vector::Vector()
{
	arr = new float[0];
	arrSize = 0;
	currentIndex = 0;
}

Vector::Vector(int size)
{
	//TODO: Dynamic allocate array by the size  
}

Vector::Vector(const Vector& V)
{
	//TODO: Copy Constructor 
}

Vector::~Vector()
{
	delete[] arr;
}

void Vector::AddNumbertoArr(float number)
{
	//TODO: Input a number into array
}

int Vector::getSize()
{
	//TODO: Return the array size

	return 0; //Remove this line
}

float Vector::length()
{
	//TODO: Compute the length of vector and return it

	return 0; //Remove this line
}

Vector Vector::normalize()
{
	//TODO: Normalize the vector and return it
	
	return Vector(); //Remove this line
}

Vector  Vector::operator+(const Vector &v)
{
	//TODO: Overload the plus operator +. 
	//Then we can use more intuitively way to add our vector (like v1 + v2).
	//Return the result of v1 + v2
	
	return Vector(); //Remove this line
}

Vector  Vector::operator=(const Vector &v)
{
	//TODO: Overload the assign operator =.
	//Then we can use more intuitively way to assign out vector (like v1 = v2).
	
	return Vector(); //Remove this line
}

Vector  Vector::operator-(const Vector &v)
{
	//TODO: Overload the subtract operator -.
	//Then we can use more intuitively way to subtract out vector (like v1 - v2).
	//Return the result of v1 - v2
	
	return Vector(); //Remove this line
}

float  Vector::operator*(const Vector &v)
{
	//TODO: Overload the operator * as dot product.
	//Return the dot product result of two vector
	
	return 0.0; //Remove this line
}

ifstream & operator>>(ifstream & in, Vector &v)
{
	//TODO: Overload the >> operator.
	//Read the input.txt file and store vector in v
	
	return in;
}

ostream & operator<<(ostream & out, const Vector & v)
{
	//TODO: Overload the << operator.
	//Output the vector v
	
	return out;
}
